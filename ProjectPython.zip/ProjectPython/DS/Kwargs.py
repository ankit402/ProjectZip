#kwargs means key value pair based arguements
class Car:
    def __init__(self,*args, **kwargs):
        self.speed = kwargs["s"]
        self.color = kwargs["c"]
        self.test = args

c1= Car(12 , s=120, c="red")
c2= Car(23, s="340" , c="black")


#printing data
print(f"printing first object data color : {c1.color} and speed : {c1.speed} {c1.test}")