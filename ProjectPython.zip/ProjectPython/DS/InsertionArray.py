from array import array

arraylist = array('l', [20,40,69,76,87,23,54])
arraylist.insert(1,800)
for k in arraylist:
    print(k)
print(f"print array after insertion {arraylist}")