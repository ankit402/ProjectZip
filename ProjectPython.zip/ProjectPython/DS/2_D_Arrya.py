from array import *

Array = [[1,2,3,4],
         [3,5,6,7],
         [5,7,8,9],
         [1,5,3,4]]
print("Iteration for normal column & Rows")
for i in Array:  # full array
    for j in i:  #column run only at the time of rows count
        print(j, end=" ")
    print()
Array.insert(2, [22,13,43,15])
print("Iteration for normal column & Rows after updating data in the array")
for k in Array:
    for l in k:
        print(l, end =" ")
    print()