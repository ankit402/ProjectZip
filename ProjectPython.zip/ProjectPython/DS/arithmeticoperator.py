# integer data type variable
#
# 2. Float data type variable
#
# 3. Complex data type variable
#
# 4. String data type variable

x= 10
y=20
print(f"print integer variable {x+y}")
print(f"print integer variable {float(x)+float(y)}")
print(f"print Complex variable {complex(x)+complex(y)}")
print(f"print String variable {str(x)+str(y)}")
