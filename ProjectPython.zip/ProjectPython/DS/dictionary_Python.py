dict ={
    'Name' : 'Ankit',
    'Age' : 32,
     'class' :'C'
}
dict['Name'] = "Rahul"   #update dictionary
del dict['Name']
del dict
print ("dict['Age']: ", dict['Age'])