tup1 = ()
print(type(tup1))
tup1 = ('A', 'B', 'C')
tup2 = ()