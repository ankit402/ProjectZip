def example_function(*args):
    print(type(args))


example_function(1,243,5)