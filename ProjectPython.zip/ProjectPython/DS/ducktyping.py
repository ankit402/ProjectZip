class Bird:
    def fly(self):
        print("bird can fly with wings")

class Airplane:
    def fly(self):
        print("fly with fuel")

class Fish:
    def swim(self):
        print("fish can swim in sea")

class swimmer:
    def swim(self):
        print("Swimmer can swim in swimming pool")

#attribute have same name
#consider duck typing


for obj in Bird(), Airplane():
    obj.fly()