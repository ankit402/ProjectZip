
# duck typing basically using in dynamic language there we do not check the types and all we do check only method or attribute here type or class in less important than method
#
print("********************Duck typing**************************")
# class specialstring:
#     def __len__(self):
#         return 21
#
#
# #driver's code
# if __name__ == "__main__":
#     string =specialstring()
#     print(len(string))

file=open("C:\images.jpg", "rb")
f2=open("C:\images3.jpg", "wb")
for i in file:
    f2.write(i)




