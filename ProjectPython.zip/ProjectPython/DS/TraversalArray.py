from array import array
# Define an array of strings (you can use a list instead of array if you want to store strings)
array_names = array("i", [10,20,30,40,50,60])
# Print each element in the array
for month in array_names:
    print(f"Month: {month}")

