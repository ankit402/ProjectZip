list1 = ['printer', 'paper', 'chip', 'card']
print(list1[3])
del list1[2]
print(list1)
list1[2] = 2001
print(list1[0:4])
list2 = ["tommy", "bhobho"]
list1 += list2
for i in list1:
    print(i)
    print(len(list1))