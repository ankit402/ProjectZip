from smartcard.System import readers
from smartcard.util import toHexString


def send_apdu(apdu_command):
    try:
        # Establish connection with the first available reader
        r = readers()
        if len(r) == 0:
            print("No smartcard readers found.")
            return

        reader = r[0]
        print(f"Using reader: {reader}")

        connection = reader.createConnection()
        connection.connect()

        # Send APDU command
        response, sw1, sw2 = connection.transmit(apdu_command)

        # Print response
        response_hex = toHexString(response)
        print(f"Response: {response_hex}")
        print(f"SW1: {hex(sw1)}, SW2: {hex(sw2)}")

        connection.disconnect()

        # Return SW2 as a hex string for potential future use
        return hex(sw2)

    except Exception as e:
        print(f"Error: {e}")
        return None


# Example APDU command to select Card Manager (AID 0x3F00)
apdu_command_select = [0x00, 0xA4, 0x04, 0x00, 0x08, 0xA0, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00]


# Example APDU command using SW2 from the previous response
def send_second_apdu(sw2_hex):
    if sw2_hex is None:
        print("Previous command failed. Cannot send second APDU.")
        return

    try:
        # Convert hex string back to integer
        sw2_int = int(sw2_hex, 16)
        print(hex(sw2_int))
        # Example second APDU command using the received SW2
        apdu_command_second = [0x00, 0xC0, 0x00, 0x00, "", 0x69]

        # Send the second APDU command
        sw2_response = send_apdu(apdu_command_second)

        if sw2_response is not None:
            print(f"Second APDU Response SW2: {sw2_response}")

    except ValueError as ve:
        print(f"Invalid hex format: {sw2_hex}")


# Send the first APDU command
sw2_hex = send_apdu(apdu_command_select)

# Send the second APDU command using the SW2 from the first response
send_second_apdu(sw2_hex)
