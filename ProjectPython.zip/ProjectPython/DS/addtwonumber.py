class TESTnumber:
    def __init__(self, *args):
        self.total = sum(args)

    def __str__(self):
        return str(self.total)


c1=TESTnumber(1,3,4)
c2=TESTnumber(3,4,5,6,7,3,2,3,4,3,2,4,5)
print(c1)
print(c2)
