class general:
    def __init__(self,*args,  **kwargs):
        self.age = kwargs["a"]
        self.name = kwargs["n"]
        for i in args:

            print(i)
        self.test = i
c1= general(12 ,34, 67 ,8 , 9, a =33, n="ankit")

print(c1.test)
