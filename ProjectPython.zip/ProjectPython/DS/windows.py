import tkinter as tk
from tkinter import messagebox
import pythonreader
import os

def print_hello():
    try:
        atr = pythonreader.getAtr()
        messagebox.showinfo("ATR", f"Card ATR: {atr}")
        print(f"Card ATR: {atr}")
    except Exception as e:
        messagebox.showerror("Error", f"Error occurred: {e}")

def clear_screen():
    try:
        if os.name == 'posix':
            _ = os.system('clear')  # For macOS and Linux
        else:
            _ = os.system('cls')    # For Windows
    except Exception as e:
        messagebox.showerror("Error", f"Error occurred while clearing screen: {e}")

def main():
    window = tk.Tk()
    window.title('Get ATR from the Chip Card')

    # Label
    label = tk.Label(window, text="Click 'Read ATR' to get card ATR.")
    label.pack(pady=10)

    # Buttons
    btn_read_atr = tk.Button(window, text="Read ATR", command=print_hello)
    btn_read_atr.pack(pady=10)

    btn_clear_screen = tk.Button(window, text="Clear Screen", command=clear_screen)
    btn_clear_screen.pack(pady=10)

    # Start the tkinter main loop
    window.mainloop()

if __name__ == "__main__":
    main()
