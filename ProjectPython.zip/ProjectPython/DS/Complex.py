class ComplexNumber:
    def __init__(self,r,i):
        self.real= r
        self.imaginary= i
    def __add__(self,others):
        return str(self.real+others.real) + "+" + str(self.imaginary+others.imaginary) +"i"

c1= ComplexNumber(5,8)
c2 = ComplexNumber(1,2)

print(c1+c2)