# integer data type variable
#
# 2. Float data type variable
#
# 3. Complex data type variable
#
# 4. String data type variable

x= 9
print(f"Print integer type variable {type(x)}and value {x}")
y= float(x)
print(f"Print Float type variable {type(y)}and value {y}")
z= complex(x)
print(f"Print complex type variable {type(z)} and value {z}")
x ="9"
print(f"Print complex type variable {type(x)}and value {x}")
