#1 Traverse
#2 Insertion
#3 Deletion
#4 Search

#Traversing array implement to visit all element to the array
from array import *
#syntax arrayname =array(typecode, [initialize])
#typecode is the value which will define which kind of value hold in the array
#Traversing elements in the array via for loop
print("Traversing elements in the array")
arrayvalue = array('i',[10,20,30,40,50,30,23,56])
for l in arrayvalue:
    print(l)
print(len(arrayvalue))
storedataarray = arrayvalue[0]
print(storedataarray)
print("Insertion the element in the array")
arrayvalue.insert(1,80) #insertion in the array
for l in arrayvalue:
    print(l)
print(len(arrayvalue))

print("Deletion of the element in the array")
arrayvalue.remove(40)
for l in arrayvalue:
    print(l)
print(len(arrayvalue))

#Searching in the array elements
index = arrayvalue.index(23)
print(index)