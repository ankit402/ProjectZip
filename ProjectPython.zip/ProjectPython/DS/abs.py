class test:
    def __int__(self):
        pass

