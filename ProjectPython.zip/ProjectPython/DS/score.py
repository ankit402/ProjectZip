import  random
import random

# Generate a random integer between 0 and 37
i = random.randint(0, 37)

# Print the message with the random integer
print(f'My highest score: {i}')