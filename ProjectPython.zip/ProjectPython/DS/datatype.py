print("*************************List*************************")
list1= ["apple", "graphs" , "mango"]
print(type(list1))
print(list1[0])

print("********************Tuple***************************")
tuple1 = ("apple", "graphs" , "mango")
print(type(tuple1))
print(tuple1[2])

print("********************Set***************************")
#unordered unindex and unchanged
set = {"apple", "graphs" , "mango","graphs" , "apple"}
print(type(set))
print(set)


print("********************Dictionary***************************")
#unordered unindex and unchanged
Dict = {
 "name" : "ankit",
    "Age" : 24
}
print(type(Dict))
print(Dict["name"])
