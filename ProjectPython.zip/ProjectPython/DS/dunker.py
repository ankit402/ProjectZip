class Author:
    def __init__(self, name, book, pages):
            self.name= name
            self.book = book
            self.pages = pages
    def __str__(self):
        return f"{self.name} by {self.book}"

d=Author("ankit", "test", 200)
print(d)


        