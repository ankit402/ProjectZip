class SubstractNumber:
    def __init__(self, *args):
        self.total = 0  # Initialize total to 0

        for i in args:
            self.total -= i

    def __str__(self):
        return str(self.total)

c1 = SubstractNumber(1, 2, 7, 8,8, 5, 4)
print(c1)  # Output: -3

