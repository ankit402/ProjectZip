# function in the python series

def my_function():
    print("call my function today")
    for x in "Ankit":
        print(x)


my_function()