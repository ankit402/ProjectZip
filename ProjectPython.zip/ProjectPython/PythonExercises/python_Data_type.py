x= 5
print(type(x))
y = "ankit"
print(type(y))
z= True
print(type(z))
a = (1,2,"ankit")
print(type(a))
b = ["new ", "old"]
print(type(b))
c = {3, 7 , True , 45}
print(type(c))
d = range(5)
print(type(d))
e = { "name" : "Ankit" , "age" : 34 } # key value pair based datatpye
print(type(e))
f = 5.78
print(type(f))
g = frozenset({"apple", "banana", "cherry"}) #user define class type
print(type(g))