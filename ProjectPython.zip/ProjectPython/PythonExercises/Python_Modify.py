#Modify the string in the python
x = "AnKit"
print(x.upper()) #convert into caps all string
y = "PANDEY"
print(y.lower()) #convert into lower all string
z = "Splitting  45   the  data"
print(z.split())  #remove unwanted spaces in the string
print(z.replace("S", "K")) #replacing the character in the string
print(z.split(","))

print(z.find("t")) #	Searches the string for a specified value and returns the position of where it was found
print(z.format())

print(z.isalnum())

print(z.endswith("date"))


