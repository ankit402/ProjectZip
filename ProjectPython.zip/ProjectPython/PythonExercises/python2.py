#python variables
x= 5
print(x)
y= 'Ankit'
print(y)

_x_y = "test"
print(_x_y)