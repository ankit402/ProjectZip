x = 5
y = 4.6
z = 1j

print(type(x))
print(type(y))
print(type(z))