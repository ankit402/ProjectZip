x= "Hello my function"
print(f"Print length of the string : {len(x)}")

#get the first character of the string
print(f"Get the first character of the string : {x[0]}")

#Get the characters from index 2 to 4 (llo)
print(f"Get the characters from index 2 to 4 (llo) : {x[2:5]}")

#Return the string without any whitespace at the beginning or the end
print(f"Return the string without any whitespace at the beginning or the end : {x.strip()}" )

