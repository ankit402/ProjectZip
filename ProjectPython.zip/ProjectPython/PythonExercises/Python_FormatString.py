
age =34
name = f"My name is Ankit and age {age}" #F string for concatenate the strings 
print(name)