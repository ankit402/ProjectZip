x = "56"
print("Before casting " ,type(x))
y = int(x)
print("After Casting ", type(y))