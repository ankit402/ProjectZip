a , b = 10 ,5
if b > a:
    print("b is greater than a")
else:
    print("a is greater than b")