month_names = ['January', 'February', 'March',      # These are the
               'April',   'May',      'June',       # Dutch names
               'July',    'August', 'September',  # for the months
               'October', 'November', 'December']   # of the year
i =1
for i in range(1,13):
            print(f"  {i} is month, {month_names[i-1]}")