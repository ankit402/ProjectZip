x ,y = 5, 10
if x > y:
    print("X is greater than y")
else:
    print("X is less than y")


a =33
b =33
if b >a:
    print("b is greater than")
elif b == a:
    print("b is equal to a")
    