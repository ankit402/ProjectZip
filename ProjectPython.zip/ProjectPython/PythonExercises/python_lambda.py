#lambda function can take any argument but only one expression

#lambda argument : expression

y = lambda k : k +10
print(y(6))

multi = lambda x , b : x*b
print(f"lambda function for multiplication {multi(6,7)}")

sum = lambda a, b, c ,d : a+ b+c*d
print(f"lambda function for perform above expression {sum(6,5,10, 10)}")

