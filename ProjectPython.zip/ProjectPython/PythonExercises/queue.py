from collections import deque
queue = deque(["1", "2", "4"])
queue.append("Ankit")
print(queue)
queue.popleft()
queue.appendleft("test")
print(queue)