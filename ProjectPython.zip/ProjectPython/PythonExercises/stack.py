stack =[3,4,5]
stack.append(6)
print(stack)
print(type(stack))
stack.pop()
print(stack)