#Use that function definition to make a function that always sum the number you send in:

def myfunc(n):
    return lambda s : s+n

myfunction = myfunc(4)
print(myfunction(2))

#Or, use the same function definition to make a function that always triples the number you send in:
def myfunc(n):
    return lambda k : k *n

multiplier = myfunc(3)
print(multiplier(12))

#Or, use the same function definition to make both functions, in the same program:

def newfunc(n):
    return lambda k : k*n

mydoubler = newfunc(2)
mytripler = newfunc(3)

print(mydoubler(12))
print(mytripler(18))