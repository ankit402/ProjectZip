x= "myfunctioncall"

def call():
    print("calling to myfunction : " + x)


call()