def my_function_Wthparam(fname):
    print(f"my name {fname}")

def my_function_Wthparamlastname(lname):
    print(f"my name {lname}")



my_function_Wthparam("Ankit")

my_function_Wthparamlastname("Pandey")