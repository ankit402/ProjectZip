a, b,c = "test1" , 4 , True

print(a)
print(b)
print(c)