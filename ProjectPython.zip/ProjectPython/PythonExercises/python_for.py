for x in "Ankit":
    print(x)